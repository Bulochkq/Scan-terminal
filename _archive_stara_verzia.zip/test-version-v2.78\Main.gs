/**
 * MAIN.GS
 * 
 * ЧОМУ ЦЕЙ ФАЙЛ ТУТ:
 * Це "вхідні двері" твого додатку. Тут ми тримаємо:
 * 1. Глобальні налаштування (константи), які використовуються всюди.
 * 2. Функцію doGet(), яка запускає додаток.
 * 3. Функцію include(), яка є "клеєм" для з'єднання HTML, CSS та JS.
 */

// --- ГЛОБАЛЬНІ КОНСТАНТИ (Налаштування) ---
var DEPLOYMENT_URL = "https://script.google.com/macros/s/AKfycbz-RY6-r9Q6FrYjCw-HiWNo5V1UAPUtwgqs15mgS1XgZMmQN0KRqhDlPUZP6cF2opRJoA/exec";
var logSheetName = "Log";
var importSheetName = "FLEX_IMPORT";
var settingsSheetName = "NASTAVENIA";
var dbStartRow = 2;
var ADMIN_PIN = "85592";

/**
 * Головна функція запуску веб-додатку.
 * Ми змінили її, щоб вона використовувала шаблон (Template), 
 * що дозволяє нам використовувати функцію include().
 */
function doGet(e) {
  // Використовуємо createTemplateFromFile замість createHtmlOutputFromFile
  return HtmlService.createTemplateFromFile('Index')
      .evaluate() // "Збирає" всі файли разом
      .setTitle('📦 SKLADOVÝ TERMINÁL v2.52')
      .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL)
      .addMetaTag('viewport', 'width=device-width, initial-scale=1, maximum-scale=1, user-scalable=0');
}

/**
 * Функція-помічник для підключення файлів.
 * Вона бере вміст файлу (наприклад, Styles.html) і вставляє його в Index.html.
 */
function include(filename) {
  return HtmlService.createHtmlOutputFromFile(filename).getContent();
}

// --- МЕНЮ ДЛЯ ГУГЛ ТАБЛИЦІ ---

function onOpen() {
  SpreadsheetApp.getUi()
      .createMenu('TERMINÁL (Admin)')
      .addItem('▶️ Otvoriť terminál', 'openAudioPanel')
      .addItem('🌍 Otvoriť na celú obrazovku', 'openWebAppLauncher')
      .addToUi();
}

function openAudioPanel() {
  // Тут теж використовуємо Index, щоб бічна панель виглядала так само
  var html = HtmlService.createTemplateFromFile('Index').evaluate().setTitle('📦 SKLADOVÝ TERMINÁL').setWidth(350);
  SpreadsheetApp.getUi().showSidebar(html);
}

function openWebAppLauncher() {
  var html = '<div style="text-align:center; font-family:sans-serif; padding:10px;">' +
      '<a href="' + DEPLOYMENT_URL + '" target="_blank" style="background:#1a73e8; color:white; text-decoration:none; padding:12px 20px; border-radius:8px; font-weight:bold; font-size:16px; display:block;">🚀 OTVORIŤ APP</a>' +
      '<div style="margin-top:10px; color:#666; font-size:12px;">Pre mobil / tablet</div></div>';
  SpreadsheetApp.getUi().showModalDialog(HtmlService.createHtmlOutput(html).setHeight(150), '📱 Webová Verzia');
}

// Допоміжна функція для отримання листа за ID
function getSheetById(ss, id) {
  if (!id) return null;
  var sheets = ss.getSheets();
  for (var i = 0; i < sheets.length; i++) {
    if (sheets[i].getSheetId() == id) return sheets[i];
  }
  return null;
}
