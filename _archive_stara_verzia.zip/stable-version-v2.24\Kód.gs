// VERZIA KÓDU: 2.24 (Final Swiss Watch Edition)
var DEPLOYMENT_URL = "https://script.google.com/macros/s/AKfycbwdEiQ_8c_z_4Ta7w69pRjPecpUNAhN4Df2k3dHvLxlQ2eShWs-7a7ToGG0v4gkcImE/exec";
var logSheetName = "Log";
var importSheetName = "FLEX_IMPORT";
var settingsSheetName = "NASTAVENIA";
var dbStartRow = 2;
var ADMIN_PIN = "85592";

function doGet(e) {
  return HtmlService.createHtmlOutputFromFile('AudioSidebar')
      .setTitle('📦 SKLADOVÝ TERMINÁL v2.24')
      .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL)
      .addMetaTag('viewport', 'width=device-width, initial-scale=1, maximum-scale=1, user-scalable=0');
}

function onOpen() {
  SpreadsheetApp.getUi()
      .createMenu('TERMINÁL (Admin)')
      .addItem('▶️ Otvoriť terminál', 'openAudioPanel')
      .addItem('🌍 Otvoriť na celú obrazovku', 'openWebAppLauncher')
      .addToUi();
}

function openAudioPanel() {
  var html = HtmlService.createHtmlOutputFromFile('AudioSidebar').setTitle('📦 SKLADOVÝ TERMINÁL').setWidth(350);
  SpreadsheetApp.getUi().showSidebar(html);
}

function openWebAppLauncher() {
  var html = '<div style="text-align:center; font-family:sans-serif; padding:10px;">' +
      '<a href="' + DEPLOYMENT_URL + '" target="_blank" style="background:#1a73e8; color:white; text-decoration:none; padding:12px 20px; border-radius:8px; font-weight:bold; font-size:16px; display:block;">🚀 OTVORIŤ APP</a>' +
      '<div style="margin-top:10px; color:#666; font-size:12px;">Pre mobil / tablet</div></div>';
  SpreadsheetApp.getUi().showModalDialog(HtmlService.createHtmlOutput(html).setHeight(150), '📱 Webová Verzia');
}

function getSheetById(ss, id) {
  if (!id) return null;
  var sheets = ss.getSheets();
  for (var i = 0; i < sheets.length; i++) {
    if (sheets[i].getSheetId() == id) return sheets[i];
  }
  return null;
}

function logSystemError(msg, user) {
  Logger.log("ERROR [" + user + "]: " + msg);
  try {
     writeToLog("SYS", "ERR", "ERR", "SYSTEM ERROR", "ERROR", 0, 0, "SYSTEM", user || "Server", msg);
  } catch(e) { Logger.log("Failed to write to log sheet: " + e); }
}

function createHiddenBackup(ss, sheet) {
  try {
    var timestamp = Utilities.formatDate(new Date(), Session.getScriptTimeZone(), "yyyyMMdd_HHmmss");
    var backupName = sheet.getName() + "_BACKUP_" + timestamp;
    
    if (ss.getSheetByName(backupName)) {
       backupName += "_" + Math.floor(Math.random() * 1000);
    }

    var backup = sheet.copyTo(ss);
    backup.setName(backupName);
    backup.hideSheet(); 
    return backupName;
  } catch (e) {
    Logger.log("Backup failed: " + e.message);
    throw new Error("Backup failed: " + e.message);
  }
}

function addUser(name) {
  try {
    var ss = SpreadsheetApp.getActiveSpreadsheet();
    var sheet = ss.getSheetByName(settingsSheetName);
    if (!sheet) { sheet = ss.insertSheet(settingsSheetName); sheet.appendRow(["MENO PRACOVNÍKA"]); }
    var data = sheet.getDataRange().getValues();
    var exists = data.some(function(r){ return String(r[0]).trim().toLowerCase() === String(name).trim().toLowerCase(); });
    if (!exists && name.trim() !== "") sheet.appendRow([name.trim()]);
    return getUsersList();
  } catch (e) { logSystemError(e.message, "Admin"); return ["Error"]; }
}

function removeUser(name) {
  try {
    var ss = SpreadsheetApp.getActiveSpreadsheet();
    var sheet = ss.getSheetByName(settingsSheetName);
    if (!sheet) return getUsersList();
    var data = sheet.getDataRange().getValues();
    for (var i = 0; i < data.length; i++) {
      if (String(data[i][0]).trim() === String(name).trim()) { 
          sheet.deleteRow(i + 1); 
          break; 
      }
    }
    return getUsersList();
  } catch (e) { logSystemError(e.message, "Admin"); return ["Error"]; }
}

function getUsersList() {
  try {
    var ss = SpreadsheetApp.getActiveSpreadsheet();
    var userSheet = ss.getSheetByName(settingsSheetName);
    var users = ["Skladník 1"]; 
    if (userSheet && userSheet.getLastRow() >= 2) {
      var raw = userSheet.getRange(2, 1, userSheet.getLastRow() - 1, 1).getValues().flat();
      var filtered = raw.filter(function(u) { return u && String(u).trim() !== ""; });
      if (filtered.length > 0) users = filtered.map(function(u){ return String(u).trim(); });
    }
    return users;
  } catch (e) { return ["Skladník 1"]; }
}

function getRecentLogs(sheetName) {
  try {
    var ss = SpreadsheetApp.getActiveSpreadsheet();
    var logSheet = ss.getSheetByName(logSheetName);
    if (!logSheet) return [];
    
    var lastRow = logSheet.getLastRow();
    if (lastRow < 2) return []; 
    
    var startRow = Math.max(2, lastRow - 150); 
    var numRows = lastRow - startRow + 1;
    if (numRows < 1) return [];

    var data = logSheet.getRange(startRow, 1, numRows, 10).getValues(); 
    
    var logs = [];
    for (var i = data.length - 1; i >= 0; i--) {
      var row = data[i];
      var rSheet = String(row[6]); 
      if (rSheet === sheetName) { 
         var timeStr = String(row[0]);
         if (Object.prototype.toString.call(row[0]) === '[object Date]') {
            timeStr = Utilities.formatDate(row[0], Session.getScriptTimeZone(), "dd.MM.yyyy HH:mm:ss");
         }

         logs.push({
           time: timeStr,
           plu: String(row[1]),
           mpn: String(row[2]),
           ean: String(row[3]),
           name: String(row[4]),
           action: String(row[5]),
           user: String(row[7]),
           oldVal: String(row[8]), 
           newVal: String(row[9])
         });
      }
      if (logs.length >= 150) break; 
    }
    return logs;
  } catch (e) { return []; }
}

function getLogsForClient(sheetId) {
  try {
      var ss = SpreadsheetApp.getActiveSpreadsheet();
      var sheet = getSheetById(ss, sheetId);
      if(!sheet) return [];
      return getRecentLogs(sheet.getName());
  } catch(e) { return []; }
}

function acquireSheetLock(sheetId, user, sessionId) {
  if (!sheetId) return { success: false };
  var cache = CacheService.getScriptCache();
  var lockKey = "ACTIVITY_" + sheetId; 
  
  var otherUser = null;
  var cachedJson = cache.get(lockKey);
  var now = Date.now();
  
  if (cachedJson) {
    var cachedData = JSON.parse(cachedJson);
    if (cachedData.id !== sessionId && (now - (cachedData.time || 0) < 35000)) {
       otherUser = cachedData.user;
    }
  }
  
  if (!otherUser) {
      cache.put(lockKey, JSON.stringify({ user: user, id: sessionId, time: now }), 40);
  }
  
  var allReals = [];
  try {
      var ss = SpreadsheetApp.getActiveSpreadsheet();
      var sheet = getSheetById(ss, sheetId);
      if(sheet) {
        var lastRow = sheet.getLastRow();
        if (lastRow >= dbStartRow) {
          allReals = sheet.getRange(dbStartRow, 7, lastRow - dbStartRow + 1, 1).getValues().flat();
          allReals = allReals.map(function(v) { return Math.floor(Number(v) || 0); });
        }
      }
  } catch(e) {
      logSystemError("Sync Read Error: " + e.message, user);
  }

  return { success: true, allReals: allReals, otherUser: otherUser };
}

function releaseSheetLock(sheetId, user, sessionId) {
  if (!sheetId) return;
  var cache = CacheService.getScriptCache();
  var lockKey = "ACTIVITY_" + sheetId;
  var cachedJson = cache.get(lockKey);
  if (cachedJson) {
      var cachedData = JSON.parse(cachedJson);
      if (cachedData.id === sessionId) {
        cache.remove(lockKey);
      }
  }
}

function getInitData() {
  try {
    var ss = SpreadsheetApp.getActiveSpreadsheet();
    var sheets = ss.getSheets();
    var sheetList = [];
    var blocked = [logSheetName, importSheetName, settingsSheetName, "Log", "LOG", "log"];
    for (var i = 0; i < sheets.length; i++) {
      var s = sheets[i];
      var n = s.getName();
      if (blocked.indexOf(n) === -1 && n.indexOf("_BACKUP") === -1 && !s.isSheetHidden()) {
        sheetList.push({ name: n, id: s.getSheetId() });
      }
    }
    // Safe user list
    var safeUsers = ["Skladník 1"];
    try { safeUsers = getUsersList(); } catch(e) { Logger.log("User list error: " + e); }
    
    return { sheets: sheetList, users: safeUsers, deployUrl: DEPLOYMENT_URL };
  } catch (e) { 
    Logger.log("Critical Init Error: " + e.message);
    return { sheets: [], users: ["Error: " + e.message], deployUrl: "" }; 
  }
}

function getSheetData(sheetId, user, sessionId) {
  if (!sheetId) return { status: "error", msg: "Nebol vybraný žiadny hárok" };

  try {
    var ss = SpreadsheetApp.getActiveSpreadsheet();
    var sheet = getSheetById(ss, sheetId);
    if (!sheet) return { status: "error", msg: "SHEET_NOT_FOUND" };
    
    var lockRes = acquireSheetLock(sheetId, user, sessionId);
    
    var lastRow = sheet.getLastRow();
    var db = [];
    if (lastRow >= dbStartRow) {
      var range = sheet.getRange(dbStartRow, 1, lastRow - dbStartRow + 1, 9);
      var data = range.getValues();
      db = data.map(function(r, i) {
        return {
          row: dbStartRow + i,
          brand: String(r[0]),
          plu: String(r[1]),
          name: r[2],
          code: String(r[3]),
          ean: String(r[4]),
          plan: Math.floor(Number(r[5]) || 0),
          real: Math.floor(Number(r[6]) || 0),
          note: String(r[8] || "") 
        };
      });
    }
    return { 
      status: "success", 
      data: db, 
      sheetName: sheet.getName(), 
      otherUser: lockRes.otherUser
    }; 
  } catch(e) {
    logSystemError("Init Data Error: " + e.message, user);
    return { status: "error", msg: e.message };
  }
}

function saveProductNote(sheetId, row, noteText, user, sessionId) {
  if (!sheetId) return { status: "error", msg: "No sheet ID" };
  
  acquireSheetLock(sheetId, user, sessionId);
  var lock = LockService.getScriptLock();
  try { lock.waitLock(5000); } catch(e) { return { status: "retry", msg: "Server busy" }; }

  try {
    var ss = SpreadsheetApp.getActiveSpreadsheet();
    var sheet = getSheetById(ss, sheetId);
    if (!sheet) return { status: "error", msg: "SHEET_NOT_FOUND" };
    
    var range = sheet.getRange(row, 9);
    var oldNote = String(range.getValue() || "");
    var rawInput = String(noteText || "").trim();
    
    var finalNoteToSave = "";
    if (rawInput !== "") {
       finalNoteToSave = rawInput + " / " + user;
    }

    if (oldNote !== finalNoteToSave) {
       range.setValue(finalNoteToSave);
       
       var timestamp = Utilities.formatDate(new Date(), Session.getScriptTimeZone(), "dd.MM.yyyy HH:mm:ss");
       var infoRange = sheet.getRange(row, 2, 1, 4);
       var info = infoRange.getValues()[0];
       
       writeToLog(info[0], info[2], info[3], info[1], "POZNÁMKA", oldNote, finalNoteToSave, sheet.getName(), user, timestamp);
    }
    return { status: "success", note: finalNoteToSave };
  } catch(e) {
    logSystemError("Note Save Error: " + e.message, user);
    return { status: "error", msg: e.message };
  } finally {
    lock.releaseLock();
  }
}

function processQueueItem(item, sheetId, user, sessionId) {
  if (!sheetId) return { status: "error", msg: "No sheet ID" };
  
  if (item.forceValue === undefined || item.forceValue === null) {
       return { status: "error", msg: "Invalid Value (Null)" };
  }
  var newQty = Number(item.forceValue);
  if (isNaN(newQty)) {
       return { status: "error", msg: "Invalid Value (NaN)" };
  }
  newQty = Math.floor(newQty);
  if (newQty < 0) newQty = 0; 

  acquireSheetLock(sheetId, user, sessionId);
  var lock = LockService.getScriptLock();
  try { lock.waitLock(5000); } catch(e) { return { status: "retry", msg: "Server busy" }; }

  try {
    var ss = SpreadsheetApp.getActiveSpreadsheet();
    var sheet = getSheetById(ss, sheetId);
    if (!sheet) return { status: "error", msg: "SHEET_NOT_FOUND" };
    
    var range = sheet.getRange(item.row, 7);
    var serverOldQty = Math.floor(Number(range.getValue()) || 0);
    var logOldQty = (item.clientOldValue !== undefined) ? item.clientOldValue : serverOldQty;

    if (newQty !== serverOldQty || logOldQty !== newQty) {
      range.setValue(newQty);
      
      var actionLabel = (item.type === "scan") ? "SKEN" : "MANUÁL";
      var timestamp = item.timestamp || Utilities.formatDate(new Date(), Session.getScriptTimeZone(), "dd.MM.yyyy HH:mm:ss");
      var infoRange = sheet.getRange(item.row, 2, 1, 4);
      var info = infoRange.getValues()[0];
      
      writeToLog(info[0], info[2], info[3], info[1], actionLabel, logOldQty, newQty, sheet.getName(), user, timestamp);
      SpreadsheetApp.flush(); 
    }
    return { status: "success", newReal: newQty };
  } catch(e) { 
    logSystemError("Write Error: " + e.message, user);
    return { status: "error", msg: e.message }; 
  } finally { 
    lock.releaseLock(); 
  }
}

function writeToLog(plu, mpn, ean, name, action, oldQty, newQty, sheetName, user, timestampStr) {
  try {
    var ss = SpreadsheetApp.getActiveSpreadsheet();
    var logSheet = ss.getSheetByName(logSheetName);
    if (!logSheet) {
      logSheet = ss.insertSheet(logSheetName);
      logSheet.appendRow(["Čas", "PLU", "SKU", "EAN", "Názov tovaru", "Akcia", "Hárok", "Užívateľ", "Bolo", "Je"]);
    }

    if (logSheet.getLastRow() >= 5000) {
       try {
         createHiddenBackup(ss, logSheet);
         logSheet.getRange(2, 1, logSheet.getLastRow() - 1, 10).clearContent();
       } catch(e) {
         Logger.log("Log rotation failed: " + e);
       }
    }
    // Force timestamp as string to avoid JSON issues
    var ts = String(timestampStr);
    logSheet.appendRow([ts, plu, mpn, ean, name, action, sheetName, user, oldQty, newQty]);
  } catch(e) {
    Logger.log("Log Write Failed: " + e);
  }
}

function verifyAdminPin(inputPin) {
   return String(inputPin).trim() === ADMIN_PIN;
}

function runImportFromSidebar(targetSheetId, password) {
  if (!verifyAdminPin(password)) {
      writeToLog("ADMIN", "AUTH", "FAIL", "IMPORT ATTEMPT", "DENIED", 0, 0, "SYSTEM", "Unknown", new Date());
      return {success: false, msg: "⛔ CHYBA: Nesprávne admin heslo!"};
  }

  var lock = LockService.getScriptLock();
  try { lock.waitLock(10000); } catch(e) { return {success: false, msg: "Server busy - Try later"}; }
  
  try {
    var ss = SpreadsheetApp.getActiveSpreadsheet();
    var targetSheet = getSheetById(ss, targetSheetId);
    if (!targetSheet) return {success: false, msg: "Cieľový hárok neexistuje"};

    var impSheet = ss.getSheetByName(importSheetName);
    if (!impSheet) { ss.insertSheet(importSheetName); return {success: false, msg: "Vložte dáta do hárku 'FLEX_IMPORT' a skúste znova."}; }
    
    var data = impSheet.getDataRange().getValues();
    if (data.length < 2) return {success: false, msg: "Hárok FLEX_IMPORT je prázdny"};

    var headers = data[0].map(function(h) { return String(h).toLowerCase().trim(); });
    var colMap = { plu: headers.indexOf("kód karty"), name: headers.indexOf("názov karty"), code: headers.indexOf("kód používaný výrobcom"), ean: headers.indexOf("čiarový kód"), plan: -1, brand: 0 };
    for (var i = 0; i < headers.length; i++) { if (headers[i].indexOf("disponibiln") !== -1) { colMap.plan = i; break; } }
    
    if (colMap.plu === -1) return {success: false, msg: "Nenašli sa stĺpce (PLU, Názov...). Skontrolujte Flex export."};
    
    var seenKeys = {}; var newData = [];
    var brandRegex = /\[(.*?)\]/;

    for (var r = 1; r < data.length; r++) {
      var row = data[r];
      var rawPlu = row[colMap.plu];
      if (!rawPlu) continue;
      var key = String(rawPlu).trim(); 
      if (seenKeys[key]) return {success: false, msg: "❌ CHYBA: Nájdený duplikát PLU: " + key + ". Import zrušený."};
      seenKeys[key] = true;
      var plan = (colMap.plan > -1 && row[colMap.plan]) ? Math.floor(Number(row[colMap.plan])) : 0;
      
      var brandVal = "";
      if (row[colMap.brand]) {
        var brandMatch = String(row[colMap.brand]).match(brandRegex);
        if (brandMatch && brandMatch[1]) brandVal = brandMatch[1];
      }

      newData.push([brandVal, key, row[colMap.name], (colMap.code > -1 ? row[colMap.code] : ""), (colMap.ean > -1 ? String(row[colMap.ean]) : ""), plan, 0, "", ""]); 
    }
    
    var backupMsg = "";
    if (targetSheet.getLastRow() > 1) {
       try {
         var bName = createHiddenBackup(ss, targetSheet);
         backupMsg = " (Záloha: " + bName + ")";
       } catch(e) {
         return {success: false, msg: "❌ Import zastavený: Zlyhala záloha! (" + e.message + ")"};
       }
    }

    targetSheet.clear(); 
    targetSheet.getRange(1, 1, 1, 9).setValues([["Značka", "PLU", "Názov karty", "SKU", "EAN", "Plán", "Realita", "Rozdiel", "Poznámka"]]);
    targetSheet.getRange(1, 1, 1, 9).setFontWeight("bold").setBackground("#d9ead3").setBorder(true, true, true, true, true, true);
    if (newData.length > 0) {
      targetSheet.getRange(2, 1, newData.length, 9).setValues(newData);
      targetSheet.getRange(2, 8, newData.length, 1).setFormulaR1C1("=N(RC[-1])-RC[-2]");
      targetSheet.getRange(2, 1, newData.length, 9).setHorizontalAlignment("left");
      targetSheet.autoResizeColumns(1, 9);

      var rangeH = targetSheet.getRange(2, 8, newData.length, 1);
      var rules = [];
      rules.push(SpreadsheetApp.newConditionalFormatRule().whenNumberLessThan(0).setBackground("#fecaca").setRanges([rangeH]).build());
      rules.push(SpreadsheetApp.newConditionalFormatRule().whenNumberGreaterThan(0).setBackground("#fed7aa").setRanges([rangeH]).build());
      targetSheet.setConditionalFormatRules(rules);
    }
    
    writeToLog("ADMIN", "IMPORT", "OK", "Imported " + newData.length + " items (v2.24)", "IMPORT", 0, 0, targetSheet.getName(), "Admin", new Date());
    SpreadsheetApp.flush(); 
    return {success: true, msg: "Import úspešný!" + backupMsg};
    
  } catch(e) { 
    logSystemError("Import Error: " + e.message, "Admin");
    return {success: false, msg: "Chyba: " + e.message}; 
  } finally { 
    lock.releaseLock(); 
  }
}

function runClearLogsFromSidebar(password) {
  if (!verifyAdminPin(password)) {
      return {success: false, msg: "⛔ CHYBA: Nesprávne admin heslo!"};
  }

  var lock = LockService.getScriptLock();
  try { lock.waitLock(2000); } catch(e) { return {success: false, msg: "Server busy"}; }
  try {
    var ss = SpreadsheetApp.getActiveSpreadsheet();
    var logSheet = ss.getSheetByName(logSheetName);
    if (!logSheet) return {success: false, msg: "Chyba: Log hárok neexistuje."};
    
    var bName = "";
    if(logSheet.getLastRow() > 1) {
       try {
         bName = createHiddenBackup(ss, logSheet);
         logSheet.getRange(2, 1, logSheet.getLastRow() - 1, 10).clearContent();
       } catch(e) {
         return {success: false, msg: "❌ Zlyhala záloha logov! Vymazanie zrušené."};
       }
    }
    
    logSheet.getRange(1, 1, 1, 10).setValues([["Čas", "PLU", "SKU", "EAN", "Názov tovaru", "Akcia", "Hárok", "Užívateľ", "Bolo", "Je"]]);
    writeToLog("ADMIN", "CLEAR", "OK", "Logs Cleared", "CLEAR", 0, 0, "LOGS", "Admin", new Date());
    
    return {success: true, msg: "Logy vymazané! (Záloha: " + bName + ")"};
  } catch(e) { 
    logSystemError("Clear Log Error: " + e.message, "Admin");
    return {success: false, msg: "Chyba: " + e.message}; 
  } finally { 
    lock.releaseLock(); 
  }
}